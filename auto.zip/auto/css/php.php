<?php 
	header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
    header("Access-Control-Allow-Headers: Authorization");
    header('Content-type: application/json');
	if(isset($_GET['domain-adsense'])){
		
		echo json_encode([
			["domain_name"=>"digitalgurutours.com"],
			["domain_name"=>"cscuniben.org"],
			// ["domain_name"=>"reenchungdds.com"],
			["domain_name"=>"anyxv.pro"],
			["domain_name"=>"cscuniben.org"],
			["domain_name"=>"mycedarparkdentist.com"],
			//["domain_name"=>"creeksidedentists.com"],
			["domain_name"=>"martindentalcenter.com"],
			//["domain_name"=>"storybooksmiles.com"],
			["domain_name"=>"dentistinodenton.com"],
			["domain_name"=>"drgillespie.com"],
			// ["domain_name"=>"pinnaclefamilydentistry.com"],
			// ["domain_name"=>"snappdental.com"],
			// ["domain_name"=>"mygrowingsmile.com"],
			// ["domain_name"=>"summitfamilyorthodontics.com"],
			// ["domain_name"=>"pomonadentaltx.com"],
			// ["domain_name"=>"chaneydentalpv.com"],
			// ["domain_name"=>"youraustintxdentist.com"],
			// ["domain_name"=>"delraydentalcenter.com"],
			// ["domain_name"=>"380smilesdental.com"]
		]);
	}
	if(isset($_GET['config-dom'])){
		
		echo json_encode(['iframe[id*="aswift_1"]','iframe[id*="aswift_2"]']);
	}